
/*****************************************************************************/
/* About: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.About.events({
  /*
   * Example:
   *  'click .selector': function (e, tmpl) {
   *
   *  }
   */ 
});

Template.About.helpers({
  /*
   * Example:
   *  items: function () {
   *    return Items.find();
   *  }
   */
});

/*****************************************************************************/
/* About: Lifecycle Hooks */
/*****************************************************************************/
Template.About.created = function () {
};

Template.About.rendered = function () {
};

Template.About.destroyed = function () {
};


