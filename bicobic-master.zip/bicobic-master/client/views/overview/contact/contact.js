
/*****************************************************************************/
/* Contact: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.Contact.events({
});

Template.Contact.helpers({
});

/*****************************************************************************/
/* Contact: Lifecycle Hooks */
/*****************************************************************************/
Template.Contact.created = function () {
};

Template.Contact.rendered = function () {
};

Template.Contact.destroyed = function () {
};


