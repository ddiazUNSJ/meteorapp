
/*****************************************************************************/
/* Meetup: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.Meetup.events({
  /*
   * Example:
   *  'click .selector': function (e, tmpl) {
   *
   *  }
   */
});

Template.Meetup.helpers({
  /*
   * Example:
   *  items: function () {
   *    return Items.find();
   *  }
   */
});

/*****************************************************************************/
/* Meetup: Lifecycle Hooks */
/*****************************************************************************/
Template.Meetup.created = function () {
};

Template.Meetup.rendered = function () {
};

Template.Meetup.destroyed = function () {
};


