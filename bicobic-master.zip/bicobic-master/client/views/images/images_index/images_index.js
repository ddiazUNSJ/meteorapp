
/*****************************************************************************/
/* ImagesIndex: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.ImagesIndex.events({
  /*
   * Example:
   *  'click .selector': function (e, tmpl) {
   *
   *  }
   */
});

Template.ImagesIndex.helpers({
  /*
   * Example:
   *  items: function () {
   *    return Items.find();
   *  }
   */
});

/*****************************************************************************/
/* ImagesIndex: Lifecycle Hooks */
/*****************************************************************************/
Template.ImagesIndex.created = function () {
  //console.log('created');
};

Template.ImagesIndex.rendered = function () {
  //console.log('rendered');
};

Template.ImagesIndex.destroyed = function () {
};
