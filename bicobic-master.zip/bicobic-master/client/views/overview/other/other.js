
/*****************************************************************************/
/* Other: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.Other.events({
  /*
   * Example:
   *  'click .selector': function (e, tmpl) {
   *
   *  }
   */
});

Template.Other.helpers({
  /*
   * Example:
   *  items: function () {
   *    return Items.find();
   *  }
   */
});

/*****************************************************************************/
/* Other: Lifecycle Hooks */
/*****************************************************************************/
Template.Other.created = function () {
};

Template.Other.rendered = function () {
};

Template.Other.destroyed = function () {
};


