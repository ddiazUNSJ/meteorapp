
/*****************************************************************************/
/* EditSearch: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.EditSearch.events({
  /*
   * Example:
   *  'click .selector': function (e, tmpl) {
   *
   *  }
   */
});

Template.EditSearch.helpers({
  /*
   * Example:
   *  items: function () {
   *    return Items.find();
   *  }
   */
});

/*****************************************************************************/
/* EditSearch: Lifecycle Hooks */
/*****************************************************************************/
Template.EditSearch.created = function () {
};

Template.EditSearch.rendered = function () {
};

Template.EditSearch.destroyed = function () {
};


