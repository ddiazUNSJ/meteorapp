
/*****************************************************************************/
/* PostIndex: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.PostIndex.events({
  /*
   * Example:
   *  'click .selector': function (e, tmpl) {
   *
   *  }
   */
});

Template.PostIndex.helpers({
  /*
   * Example:
   *  items: function () {
   *    return Items.find();
   *  }
   */
});

/*****************************************************************************/
/* PostIndex: Lifecycle Hooks */
/*****************************************************************************/
Template.PostIndex.created = function () {
};

Template.PostIndex.rendered = function () {
  Prism.highlightAll();
};

Template.PostIndex.destroyed = function () {
};


