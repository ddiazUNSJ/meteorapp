
/*****************************************************************************/
/* Loading: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.Loading.events({
  /*
   * Example:
   *  'click .selector': function (e, tmpl) {
   *
   *  }
   */
});

Template.Loading.helpers({
  /*
   * Example:
   *  items: function () {
   *    return Items.find();
   *  }
   */
});

/*****************************************************************************/
/* Loading: Lifecycle Hooks */
/*****************************************************************************/
Template.Loading.created = function () {
};

Template.Loading.rendered = function () {
};

Template.Loading.destroyed = function () {
};


