
/*****************************************************************************/
/* PostsIndex: Event Handlers and Helpersss .js*/
/*****************************************************************************/
Template.PostsIndex.events({
  /*
   * Example:
   *  'click .selector': function (e, tmpl) {
   *
   *  }
   */
});

Template.PostsIndex.helpers({
  /*
   * Example:
   *  items: function () {
   *    return Items.find();
   *  }
   */
});

/*****************************************************************************/
/* PostsIndex: Lifecycle Hooks */
/*****************************************************************************/
Template.PostsIndex.created = function () {
};

Template.PostsIndex.rendered = function () {
  Prism.highlightAll();
};

Template.PostsIndex.destroyed = function () {
};


