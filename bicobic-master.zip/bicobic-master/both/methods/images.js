/*****************************************************************************/
/* Images Methods */
/*****************************************************************************/

Meteor.methods({
 /*
  * Example:
  *  '/app/images/update/email': function (email) {
  *    Users.update({_id: this.userId}, {$set: {'profile.email': email}});
  *  }
  *
  */
});
